# Telegram Media Downloader Bot (Updated)

This is an updated version of the Telegram Media Downloader Bot with several new features.

## New Features

### 1. Dynamic Welcome System
- **Owner-only command:** `/setwelcome [fariinta]`
  - Use `{name}` in the text to address users by their Telegram name.
- **Owner-only command:** `/setimage`
  - Reply to any photo with this command to set it as the welcome image.
- **Owner-only command:** `/setchannel [URL]`
  - Change the "Update Channel" button link dynamically.

### 2. Interactive Menu
- **Help Button:** Displays a guide on how to use the bot.
- **Owner Button:** Shows contact information for the bot creator.
- **Update Channel Button:** Links to the specified Telegram channel.

### 3. Broadcast System
- **Automatic User Tracking:** Saves all user IDs who start the bot in `data/users.txt`.
- **Owner-only command:** `/broadcast [fariinta]`
  - Sends a message to every user in the database.

### 4. Reliability & Deployment
- **Keep-Alive Server:** Built-in HTTP server on port 8080 (or as specified by `PORT` env var) for Render/Koyeb.
- **Auto-Restart:** Automatically attempts to restart if the bot crashes.
- **Somali Language:** Maintained for all user-facing messages.
- **File Size Limit:** Respects the 50MB Telegram upload limit.

## Configuration

Set the following environment variables in your hosting provider:
- `BOT_TOKEN`: Your Telegram Bot Token.
- `OWNER_ID`: Your Telegram User ID (to access owner commands).
- `ENABLE_KEEP_ALIVE`: Set to `true` (default).
- `PORT`: Port for the keep-alive server (default 8080).

## Deployment

### Render / Koyeb
1. Connect your GitHub repository.
2. Set the environment variables.
3. Use the provided `Dockerfile`.
4. Ensure you use a "Web Service" type to keep the port active.
